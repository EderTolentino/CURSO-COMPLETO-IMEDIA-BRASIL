module.exports = {
  plugins: {
    'postcss-import': {},
    stylelint: {},
  },
};
