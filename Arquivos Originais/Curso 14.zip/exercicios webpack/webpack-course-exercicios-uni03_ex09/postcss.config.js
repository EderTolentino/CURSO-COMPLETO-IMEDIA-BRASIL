module.exports = {
  plugins: {
    'postcss-import': {},
    autoprefixer: { browsers: ['ie 10'] },
  },
};
