<footer>
    <div id="footer_central">
    <p>ANDES é uma empresa fictícia, usada para o curso PHP Integração com MySQL.</p>
    </div>
</footer>