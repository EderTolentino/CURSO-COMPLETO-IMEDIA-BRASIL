<!doctype html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Curso PHP Integração com MySQL</title>
    </head>

    <body>
        <?php 
            print_r(getdate());

        ?>
    </body>
</html>