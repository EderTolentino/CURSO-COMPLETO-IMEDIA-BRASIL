<footer>
    <div id="footer_central">
        <p>ANDES &eacute; uma empresa fict&iacute;cia, usada para o curso PHP Integra&ccedil;&atilde;o com MySQL.</p>
    </div>
</footer>