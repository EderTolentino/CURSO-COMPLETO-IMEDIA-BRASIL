<?php
    $arquivo = "documento.xlsx";
    echo strrchr($arquivo,".");
?>