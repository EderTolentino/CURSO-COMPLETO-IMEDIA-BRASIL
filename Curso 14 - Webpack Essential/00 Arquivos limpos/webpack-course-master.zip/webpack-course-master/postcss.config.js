module.exports = {
  plugins: {
    'postcss-import': {},
    stylelint: {},
    autoprefixer: { browsers: ['ie 10'] },
  },
};
